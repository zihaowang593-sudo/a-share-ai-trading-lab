# 股票分析工具 · iPhone IPA 工程（用于 XSign）

## 当前交付的是什么

这是 **完整 iOS 工程源代码 + 用 GitHub Actions 在 macOS 编译无签名 IPA 的流程**。因为当前生成环境没有 Xcode、iOS SDK，也没有你的 Apple 签名证书，不能在这里生成已编译可安装的 IPA。**不要把源代码 ZIP 改后缀当成 IPA**。

### 已制作

- SwiftUI + WKWebView 原生应用容器，独立桌面图标与全屏显示。
- 内置股票分析工具 V7.0 的 HTML、CSS、JavaScript，动态入站封面和个性化设置；打开本机界面无需从 GitHub Pages 下载代码。
- 本机研究数据除了 WebView 存储，还通过原生桥备份到应用的 `Application Support`，设置 iOS 文件保护级别。卸载 App 会删除这些本机数据，因此重要记录仍需定期导出 JSON。
- 原生 Google 登录接口（GoogleSignIn + Firebase Auth）和同一 Firestore `users/{uid}/private/workspace` 存储路径；Google 登录必须完成下述 iOS 应用注册后才可用。
- Google 账号数据与本机模式互相隔离；尚未配置 Google 时不伪造登录成功。
- AI 后端可选。**AI_WORKER_URL 留空时在线 GPT 无法工作**；只有安全部署了 Worker 且其访问权限和用户配额通过验证，才能开启。不要把 OpenAI API 密钥写在 iOS 工程中。

### 未完成与受外部条件限制的部分

1. **本机还没有进行 macOS/Xcode 编译**。提供的是待 GitHub Actions 编译的工程，首次构建可能需根据 Xcode/依赖版本修复兼容性。编译成功后得到的是 **unsigned IPA**，需用你的 XSign 对应证书重新签名和安装。
2. 你现有 Firebase `firebaseConfig` 是 **Web 应用配置**，无法充当原生 iOS 的 `GoogleService-Info.plist`。必须在 Firebase 项目 `planning-with-ai-fe823` 中添加 iOS 应用，Bundle ID 设置为 `com.wzh.stockanalysis`，下载官方生成的 `GoogleService-Info.plist`，放到 `StockAnalysis/App/Resources/` 目录，重新编译。构建流程会自动配置 Google OAuth URL Scheme。
3. 中国大陆联网问题尚未解决：本机模式能启动，但 Google、Firestore、TradingView 与 GPT 网络连接仍可能在当地受到限制。不要误认为 IPA 等于所有在线能力都离线可用。
4. 签名必须由有效 Apple 开发者/设备授权证书进行；XSign 本身并不代替证书或设备授权。
5. 原网页的历史本机数据不会自动进入 iOS 新沙盒；可从旧网页导出 JSON，在 App 内通过导入功能恢复。先备份再迁移。

## 最省操作的 IPA 构建方法（借用你的 GitHub 仓库）

先在本包外找到两个文件：

- `StockAnalysis-iOS-Source.zip`：把整个工程压成的文件，上传到 GitHub 仓库 `zihaowang593-sudo/a-share-ai-trading-lab` 的根目录。**ZIP 文件名不要改。**
- `build-ios-from-zip.yml`：在 GitHub 的 `Add file → Create new file` 中，新文件名填 `.github/workflows/build-ios-from-zip.yml`，粘贴该 YAML 文件内容，提交到 `main`。这个文件是构建指令，不是 IPA。

然后打开仓库 → **Actions** → `Build XSign-ready unsigned IPA` → **Run workflow**。
等待任务通过后，在该运行页面下方的 **Artifacts** 下载 `StockAnalysis-IPA-for-XSign`，解压得到 `StockAnalysis-unsigned-XSign.ipa`。把它导入 XSign，用自己的有效签名证书签名，再安装。

第一次不加 Google iOS 配置也能尝试构建本机版本。等注册 iOS Firebase 后，请在源工程的 `StockAnalysis/App/Resources` 中加入原版 `GoogleService-Info.plist` 并重新打包源码 ZIP（或克隆完整工程修改）；Google 登录需要重新编译，不是修改网页 Firebase 配置文件即可。

> 注意：把整个工程直接作为 GitHub 仓库根目录推送时，也提供了 `.github/workflows/unsigned-ipa.yml` 可直接构建的方案。上述 ZIP 方案是为了在手机上尽量减少文件上传操作。

## 代码结构

- `StockAnalysis/App/Sources/StockAnalysisApp.swift`：iOS 容器、WebView、外部链接。
- `StockAnalysis/App/Sources/NativeCloud.swift`：系统 Google 登录、Firestore 和本机受保护数据备份。
- `StockAnalysis/App/Assets.xcassets/AppIcon.appiconset`：应用图标。
- `StockAnalysis/Web/index.html`：内置 V7.0 界面与动态封面。
- `StockAnalysis/Web/native-bridge.js`：网站与 iOS 原生模块通信。
- `scripts/prepare_config.py`：从 Firebase iOS 配置读取 OAuth URL Scheme；不接触服务器私钥。
- `project.yml`：XcodeGen 工程定义。
- `.github/workflows/unsigned-ipa.yml`：整个源码提交后使用的构建工作流。

## 数据与账户安全

- Firestore 的访问权限由 Firebase Auth 与 Security Rules 负责；WebView 中即使伪造按钮状态，也不能绕过原生 Firebase 的身份验证。
- 本机备份有系统文件保护，但不代表端到端加密。设备解锁、共享设备或被攻破时仍有风险。
- 采用统一 Bundle ID 和相同签名证书更新，以减少数据丢失风险。导入 XSign 前先导出 JSON 备份。
- 动态曲线是视觉设计，不是实时行情。技术信号需要真实且足够新的授权数据。

## 如果 CI 编译失败

请把 GitHub Actions 的红色报错日志（不要包含密钥）发给我。尤其是 `Generate Xcode project` 或 `Compile iPhone app without signing` 阶段的错误；我会针对报错修复工程。
