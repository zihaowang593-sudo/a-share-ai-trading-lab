import Foundation
import UIKit
import WebKit
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore
import GoogleSignIn

/// Native auth and persistence: no service-account credentials or OpenAI key are embedded.
final class NativeCloud {
    static let shared = NativeCloud()
    private init() {}

    private weak var webView: WKWebView?
    private var ready = false
    private var configured = false
    private var authHandle: AuthStateDidChangeListenerHandle?
    private var activeUID: String?
    private var queued: [String: Any]?
    private var saveJob: DispatchWorkItem?
    private var lastLocalRestore = false
    private var activeSave = false

    func start() {
        // IMPORTANT: GoogleService-Info.plist must come from the *iOS app* registered
        // in the same Firebase project. The existing Web firebaseConfig is not interchangeable.
        guard let url = Bundle.main.url(forResource: "GoogleService-Info", withExtension: "plist"),
              let dict = NSDictionary(contentsOf: url) as? [String: Any],
              let googleAppID = dict["GOOGLE_APP_ID"] as? String,
              googleAppID.contains(":ios:") else {
            configured = false
            return
        }
        FirebaseApp.configure()
        configured = true
        authHandle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async { self?.authChanged(user) }
        }
    }

    func attach(_ view: WKWebView) { webView = view }

    func webReady() {
        ready = true
        restoreLocal()
        if configured { authChanged(Auth.auth().currentUser) }
    }

    func handle(_ body: [String: Any]) {
        guard let type = body["type"] as? String else { return }
        switch type {
        case "saveLocal":
            if let bundle = body["bundle"] as? [String: Any] { saveLocal(bundle) }
        case "signIn": signIn()
        case "signOut": signOut()
        case "queueWrite":
            guard let bundle = body["bundle"] as? [String: Any] else { return }
            queueWrite(bundle)
        case "flush": flush()
        case "callAI":
            let id = body["id"] as? String ?? ""
            let payload = body["payload"] as? [String: Any] ?? [:]
            callAI(id: id, payload: payload)
        default: break
        }
    }

    private func jsLiteral(_ value: Any) -> String? {
        guard JSONSerialization.isValidJSONObject(value),
              let data = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed, .sortedKeys]),
              let string = String(data: data, encoding: .utf8) else { return nil }
        return string
    }

    private func js(_ command: String) {
        guard ready else { return }
        DispatchQueue.main.async { [weak self] in self?.webView?.evaluateJavaScript(command, completionHandler: nil) }
    }

    private func uiError(_ message: String) {
        guard let quoted = jsLiteral([message]) else { return }
        js("window.stockCloudUI?.error?.(\(quoted)[0]);")
    }

    // MARK: Protected local backup
    private var localURL: URL? {
        guard let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let folder = base.appendingPathComponent("ResearchWorkspace", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        return folder.appendingPathComponent("local-workspace.json")
    }

    private func saveLocal(_ bundle: [String: Any]) {
        guard !configured || Auth.auth().currentUser == nil else { return }
        guard JSONSerialization.isValidJSONObject(bundle),
              let json = try? JSONSerialization.data(withJSONObject: bundle),
              json.count <= 900_000, let path = localURL else { return }
        do {
            try json.write(to: path, options: .atomic)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                                                  ofItemAtPath: path.path)
        } catch { uiError("本机备份失败：请使用设置中的 JSON 导出备份。") }
    }

    private func restoreLocal() {
        guard !lastLocalRestore, let url = localURL, let data = try? Data(contentsOf: url),
              let text = String(data: data, encoding: .utf8),
              let arg = jsLiteral([text]) else { return }
        lastLocalRestore = true
        js("window.stockLabNativeApplyBackup?.(\(arg)[0]);")
    }

    // MARK: Google Sign-In via system flow
    private func signIn() {
        guard configured else {
            uiError("iOS 原生 Google 登录尚未开通。请先在 Firebase 添加 iOS 应用并下载 GoogleService-Info.plist；本机模式可正常使用。")
            return
        }
        guard let clientID = FirebaseApp.app()?.options.clientID, !clientID.isEmpty else {
            uiError("iOS OAuth 客户端 ID 缺失；请检查 Firebase iOS 应用配置。")
            return
        }
        guard let controller = webView?.window?.rootViewController else {
            uiError("暂时无法启动系统登录页面，请重新打开应用。")
            return
        }
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        GIDSignIn.sharedInstance.signIn(withPresenting: controller) { [weak self] result, error in
            if let error = error { self?.uiError("Google 登录未完成：\(error.localizedDescription)"); return }
            guard let user = result?.user, let idToken = user.idToken?.tokenString else {
                self?.uiError("Google 登录未返回有效凭证。")
                return
            }
            let credential = GoogleAuthProvider.credential(withIDToken: idToken,
                                                             accessToken: user.accessToken.tokenString)
            Auth.auth().signIn(with: credential) { _, error in
                if let error = error { self?.uiError("Firebase 登录失败：\(error.localizedDescription)") }
                // authChanged listener loads the Firestore workspace on success.
            }
        }
    }

    private func signOut() {
        guard configured else { js("window.stockCloudUI?.signedOut?.();"); return }
        if queued != nil || activeSave {
            uiError("还有未确认同步的研究记录，请等待保存成功后再退出登录。")
            return
        }
        do {
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance.signOut()
            // authChanged will clear the owner and restore the local workspace.
        } catch { uiError("退出登录失败：\(error.localizedDescription)") }
    }

    private func authChanged(_ user: User?) {
        guard ready else { return }
        guard let user = user else {
            let wasSignedIn = activeUID != nil
            activeUID = nil
            saveJob?.cancel(); queued = nil
            // Do not overwrite freshly restored native backup at initial startup.
            if wasSignedIn { js("window.stockCloudUI?.signedOut?.();") }
            return
        }
        activeUID = user.uid
        js("window.stockCloudUI?.loading?.();")
        Firestore.firestore().collection("users").document(user.uid)
            .collection("private").document("workspace").getDocument { [weak self] snap, error in
                guard let self, self.activeUID == user.uid else { return }
                if let error = error { self.uiError("私人数据读取失败：\(error.localizedDescription)"); return }
                let record = snap?.data() ?? [:]
                let safe: [String: Any] = ["model": record["model"] ?? NSNull(),
                                           "workspace": record["workspace"] ?? NSNull()]
                guard let args = self.jsLiteral([ ["uid":user.uid,"email":user.email ?? ""], safe ]) else { return }
                self.js("window.stockCloudUI?.signedIn?.(...\(args));")
            }
    }

    // MARK: Firestore queue – per-user path matches existing Firestore security rules
    private func queueWrite(_ bundle: [String: Any]) {
        guard configured, Auth.auth().currentUser?.uid == activeUID, activeUID != nil else {
            uiError("请先用 Google 登录才能同步。")
            return
        }
        guard JSONSerialization.isValidJSONObject(bundle),
              let data = try? JSONSerialization.data(withJSONObject: bundle), data.count < 650_000 else {
            uiError("研究记录超过云数据库单文档限制，请先导出备份并精简内容。")
            return
        }
        queued = bundle
        saveJob?.cancel()
        let task = DispatchWorkItem { [weak self] in self?.flush() }
        saveJob = task
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: task)
    }

    private func flush() {
        saveJob?.cancel(); saveJob = nil
        guard !activeSave, let bundle = queued, let uid = activeUID,
              Auth.auth().currentUser?.uid == uid else { return }
        queued = nil; activeSave = true
        var data: [String: Any] = ["model":bundle["model"] ?? [:],"workspace":bundle["workspace"] ?? [:]]
        data["updatedAt"] = FieldValue.serverTimestamp()
        Firestore.firestore().collection("users").document(uid).collection("private")
            .document("workspace").setData(data) { [weak self] error in
                guard let self else { return }
                self.activeSave = false
                guard self.activeUID == uid else { return }
                if let error = error {
                    if self.queued == nil { self.queued = bundle }
                    self.js("window.stockCloudUI?.saveState?.('云端写入失败，请保留本机备份',true);")
                    print("Firestore save failed: \(error.localizedDescription)")
                } else {
                    self.js("window.stockCloudUI?.saveState?.('✓ 云端已自动保存');")
                }
                if self.queued != nil && error == nil { self.flush() }
            }
    }

    // MARK: Optional GPT Worker. Secret stays on Worker, NEVER in IPA.
    private func callAI(id: String, payload: [String: Any]) {
        guard let responseID = jsLiteral([id]) else { return }
        func fail(_ error: String) {
            guard let msg = jsLiteral([error]) else { return }
            js("window.stockLabNativeResult?.(\(responseID)[0],null,\(msg)[0]);")
        }
        guard configured, let user = Auth.auth().currentUser else { fail("请先登录 Google 账号"); return }
        guard let endpoint = Bundle.main.object(forInfoDictionaryKey: "AI_WORKER_URL") as? String,
              let url = URL(string: endpoint), url.scheme == "https",
              url.host?.hasSuffix(".workers.dev") == true, url.path == "/ai" else {
            fail("内置 GPT 服务尚未部署；请先配置 HTTPS Worker 接口")
            return
        }
        guard JSONSerialization.isValidJSONObject(payload),
              let data = try? JSONSerialization.data(withJSONObject: payload), data.count < 25000 else {
            fail("问题内容过长，请精简后重试")
            return
        }
        user.getIDToken { [weak self] token, tokenError in
            guard let self else { return }
            guard let token = token, tokenError == nil else { fail("身份验证过期，请重新登录"); return }
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.httpBody = data
            request.timeoutInterval = 55
            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error { fail("AI 网络请求失败：\(error.localizedDescription)"); return }
                guard let http = response as? HTTPURLResponse,
                      let data = data, let json = try? JSONSerialization.jsonObject(with:data) as? [String: Any] else {
                    fail("AI 服务没有返回有效数据")
                    return
                }
                if http.statusCode != 200 { fail(String(describing: json["error"] ?? "服务暂不可用")); return }
                guard let reply = json["reply"] as? String,
                      let value = self.jsLiteral([reply]) else { fail("AI 回复为空"); return }
                self.js("window.stockLabNativeResult?.(\(responseID)[0],\(value)[0],null);")
            }.resume()
        }
    }
}
