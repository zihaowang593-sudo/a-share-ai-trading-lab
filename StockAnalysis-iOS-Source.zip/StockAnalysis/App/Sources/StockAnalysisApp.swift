import SwiftUI
import UIKit
import WebKit
import GoogleSignIn

@main
struct StockAnalysisApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate

    var body: some Scene {
        WindowGroup {
            StockWebScreen()
                .background(Color(red: 0.045, green: 0.075, blue: 0.125))
                .ignoresSafeArea()
                .preferredColorScheme(.dark)
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        NativeCloud.shared.start()
        return true
    }

    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }
}

struct StockWebScreen: UIViewRepresentable {
    private static let onlinePage = URL(string: "https://zihaowang593-sudo.github.io/a-share-ai-trading-lab/v7.0.html")!
    fileprivate static let allowedHost = "zihaowang593-sudo.github.io"

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let content = WKWebViewConfiguration()
        content.websiteDataStore = .default() // Persistent on-device website data
        content.defaultWebpagePreferences.allowsContentJavaScript = true
        content.allowsInlineMediaPlayback = true
        let view = WKWebView(frame: .zero, configuration: content)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.045, green: 0.075, blue: 0.125, alpha: 1)
        view.scrollView.backgroundColor = view.backgroundColor
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.scrollView.bounces = true
        // The native bridge must also exist on the remotely hosted V7.0 page.
        if let bridgeURL = Bundle.main.url(forResource: "native-bridge", withExtension: "js", subdirectory: "Web"),
           let bridge = try? String(contentsOf: bridgeURL, encoding: .utf8) {
            content.userContentController.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        }
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        content.userContentController.add(context.coordinator, name: "stockNative")
        context.coordinator.view = view
        NativeCloud.shared.attach(view)

        context.coordinator.localPage = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web")
        var request = URLRequest(url: Self.onlinePage, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        view.load(request)
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var view: WKWebView?
        var localPage: URL?
        private var didFallback = false

        private func showOfflineFallback(_ webView: WKWebView) {
            guard !didFallback else { return }
            didFallback = true
            if let page = localPage {
                webView.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
            } else {
                webView.loadHTMLString("<p style='color:white;padding:32px'>在线页面暂不可用，请检查网络后重新打开应用。</p>", baseURL: nil)
            }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            if (error as NSError).code != NSURLErrorCancelled { showOfflineFallback(webView) }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            if (error as NSError).code != NSURLErrorCancelled { showOfflineFallback(webView) }
        }

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "stockNative", let content = message.body as? [String: Any] else { return }
            NativeCloud.shared.handle(content)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            NativeCloud.shared.webReady()
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.targetFrame?.isMainFrame != false,
               let u = navigationAction.request.url,
               (u.scheme == "https" || u.scheme == "http"),
               !(u.scheme == "https" && u.host == StockWebScreen.allowedHost && u.path.hasPrefix("/a-share-ai-trading-lab/")) {
                UIApplication.shared.open(u)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url,
               (url.scheme == "https" || url.scheme == "http") {
                UIApplication.shared.open(url)
            }
            return nil
        }
    }
}
