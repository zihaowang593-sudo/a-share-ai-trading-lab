import SwiftUI
import UIKit
import WebKit
import GoogleSignIn

@main
struct StockAnalysisApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate

    var body: some Scene {
        WindowGroup {
            StockWebScreen()
                .background(Color(red: 0.045, green: 0.075, blue: 0.125))
                .ignoresSafeArea()
                .preferredColorScheme(.dark)
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        NativeCloud.shared.start()
        return true
    }

    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }
}

struct StockWebScreen: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let content = WKWebViewConfiguration()
        content.websiteDataStore = .default() // Persistent on-device website data
        content.defaultWebpagePreferences.allowsContentJavaScript = true
        content.allowsInlineMediaPlayback = true
        let view = WKWebView(frame: .zero, configuration: content)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 0.045, green: 0.075, blue: 0.125, alpha: 1)
        view.scrollView.backgroundColor = view.backgroundColor
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.scrollView.bounces = true
        view.navigationDelegate = context.coordinator
        view.uiDelegate = context.coordinator
        content.userContentController.add(context.coordinator, name: "stockNative")
        context.coordinator.view = view
        NativeCloud.shared.attach(view)

        guard let page = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") else {
            view.loadHTMLString("<p style='color:white;padding:32px'>应用界面文件未找到，请重新构建安装包。</p>", baseURL: nil)
            return view
        }
        view.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var view: WKWebView?

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "stockNative", let content = message.body as? [String: Any] else { return }
            NativeCloud.shared.handle(content)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            NativeCloud.shared.webReady()
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.targetFrame?.isMainFrame != false,
               let u = navigationAction.request.url,
               (u.scheme == "https" || u.scheme == "http") {
                UIApplication.shared.open(u)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url,
               url.scheme == "https" || url.scheme == "http" { UIApplication.shared.open(url) }
            return nil
        }
    }
}
