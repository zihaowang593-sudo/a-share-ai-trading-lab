/* Native iOS bridge. No secret values or privileged tokens live in this web resource. */
(() => {
  'use strict';
  const post = (type, payload={}) => {
    try {window.webkit?.messageHandlers?.stockNative?.postMessage({type, ...payload});}
    catch (_) {}
  };
  let seq=0;
  const callbacks = new Map();
  window.stockLabNativeSave = bundle => post('saveLocal',{bundle});
  window.stockLabNativeApplyBackup = data => {
    try {
      if (typeof cloudMode!=='undefined' && cloudMode) return;
      const obj = typeof data==='string'?JSON.parse(data):data;
      if (!obj||!obj.model||!obj.workspace) return;
      model=sanitize(obj.model);
      workspace=sanitizeWorkspace(obj.workspace);
      restoreWorkspace();populate();refresh();
      window.stockCloudUI?.saveState?.('✓ 已恢复 iPhone 本机研究记录');
    } catch(err) {window.stockCloudUI?.saveState?.('本机备份恢复失败，请手动导入备份',true);}
  };
  window.stockLabNativeResult = (id,reply,error) => {
    const p=callbacks.get(id);if(!p)return;
    callbacks.delete(id);if(error)p.reject(new Error(error));else p.resolve(reply);
  };
  window.stockCloud = {
    signIn(){post('signIn');},
    signOut(){post('signOut');},
    queueWrite(bundle){post('queueWrite',{bundle});},
    flush(){post('flush');},
    callAI(payload){
      return new Promise((resolve,reject)=>{
        const id=String(++seq);callbacks.set(id,{resolve,reject});
        post('callAI',{id,payload});
        setTimeout(()=>{if(callbacks.has(id)){callbacks.delete(id);reject(new Error('AI 请求超时，请稍后再试'));}},62000);
      });
    }
  };
})();
