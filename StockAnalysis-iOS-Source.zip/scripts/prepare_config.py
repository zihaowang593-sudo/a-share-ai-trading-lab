"""Copies Google's registered iOS app OAuth reversed client ID into the Xcode URL scheme.
No server/API secret is read, generated, or embedded. Run before xcodegen.
"""
from pathlib import Path
import plistlib
root=Path(__file__).resolve().parents[1]
config=root/'StockAnalysis/App/Resources/GoogleService-Info.plist'
info=root/'StockAnalysis/App/Info.plist'
with info.open('rb') as f:target=plistlib.load(f)
if not config.exists():
    print('NOTICE: Firebase iOS app not yet registered; local-only mode will work. Google login stays unavailable.')
    raise SystemExit(0)
with config.open('rb') as f:source=plistlib.load(f)
app_id=str(source.get('GOOGLE_APP_ID',''))
reversed_id=str(source.get('REVERSED_CLIENT_ID',''))
if ':ios:' not in app_id or not reversed_id or source.get('BUNDLE_ID') != 'apple.98xzpbqj84.sign':
    raise SystemExit('Invalid Firebase iOS plist. Register an iOS app, not another Web app.')
target['CFBundleURLTypes']=[{'CFBundleURLName':'Google Sign-In','CFBundleURLSchemes':[reversed_id]}]
with info.open('wb') as f:plistlib.dump(target,f)
print('Firebase iOS Google Sign-in URL scheme configured (not printed to logs).')
